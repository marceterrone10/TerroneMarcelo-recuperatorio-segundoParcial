package modelo;

import java.io.Serializable;
import java.time.LocalDate;


public class EventoMusical extends Evento implements Comparable<EventoMusical>, Serializable{
    private String artista;
    private GeneroMusical genero;

    public EventoMusical(int id, String nombre, LocalDate fecha, String artista, GeneroMusical genero) {
        super(id, nombre, fecha);
        this.artista = artista;
        this.genero = genero;
    }

    public GeneroMusical getGenero() {
        return genero;
    }

    public String getArtista() {
        return artista;
    }
    
    
    public String toCSV(){
        return this.getId() + "," + this.getNombre() + "," + this.getFecha() + "," + artista + "," + genero.toString();
    }
    
    public static EventoMusical fromCSV(String eventoMusicalCSV){
        
        if(eventoMusicalCSV.endsWith("\n")){
            eventoMusicalCSV = eventoMusicalCSV.substring(0, eventoMusicalCSV.length()-1);
        }
        
        String[] valores = eventoMusicalCSV.split(",");
        
        return new EventoMusical(Integer.parseInt(valores[0]),
            valores[1],
            LocalDate.parse(valores[2]),
            valores[3],
            GeneroMusical.valueOf(valores[4]));   
    }

    @Override
    public int compareTo(EventoMusical o) {
        return this.getFecha().compareTo(o.getFecha());
    }

    @Override
    public String toString() {
        return "EventoMusical{" + "id=" + getId() + ", nombre=" + getNombre() + ", fecha=" + getFecha()  + ", artista=" + artista + ", genero=" + genero + '}';
    }

    
    
    
}
