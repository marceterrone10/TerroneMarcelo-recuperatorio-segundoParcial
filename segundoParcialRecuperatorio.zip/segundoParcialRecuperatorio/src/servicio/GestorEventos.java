package servicio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import modelo.EventoMusical;


public class GestorEventos<T extends EventoMusical & Serializable> implements Inventariable<T> {
    List<T> lista = new ArrayList<>();
    
    public void limpiar(){
        lista.clear();
    }

    @Override
    public void agregar(T item) {
        if(item==null){
            throw new IllegalArgumentException("No se pueden almacenar nulos en la lista");
        }
        lista.add(item);
    }
    
    private void validarIndice(int indice){
        if(indice < 0 || indice >= lista.size()){
            throw new IndexOutOfBoundsException("Indice invalido");
        }
    }

    @Override
    public T obtener(int indice) {
        validarIndice(indice);
        return lista.get(indice);
    }

    @Override
    public void eliminar(int indice) {
        validarIndice(indice);
        lista.remove(indice);
    }

    @Override
    public void mostrarTodos() {
        for(T item : lista){
            System.out.println(item);
        }
    }

    @Override
    public List<T> filtrar(Predicate<T> predicado) {
        List<T> toReturn = new ArrayList<>();
        for(T item : lista){
            if(predicado.test(item)){
                toReturn.add(item);
            }
        }
        return toReturn;
    }

    @Override
    public List<T> buscarPorRango(LocalDate fechaInicio, LocalDate fechaFinal) {
        List<T> toReturn = new ArrayList<>();
        
        for (T elemento : lista){
            if(elemento.getFecha().compareTo(fechaInicio) >= 0 && elemento.getFecha().compareTo(fechaFinal) <= 0){
                toReturn.add(elemento);
            }
        }
        return toReturn;
    }

    @Override
    public void ordenarNatural() {
        ordenar((Comparator<T>) Comparator.naturalOrder());
    }

    @Override
    public void ordenar(Comparator<T> criterio) {
        lista.sort(criterio);
    }

    @Override
    public void guardarEnBinario(String path) {
        try(ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))){
            salida.writeObject(lista);
        } catch(IOException ex){
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void cargarDesdeBinario(String path) {
        try(ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))){
            lista= (List<T>) input.readObject();
        
        } catch(IOException | ClassNotFoundException ex){
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void guardarEnCSV(String path) {
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(path))){  
            bw.write("id,nombre,fecha,artista,genero\n");
            for(T elemento : lista){
                bw.write(elemento.toCSV()+ "\n");
            }
        } catch (IOException ex){
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void cargarDesdeCSV(String path, Function<String, T> funcion) {
        lista.clear();
        try(BufferedReader br = new BufferedReader(new FileReader(path))){  
            String linea;
            br.readLine();
            while((linea = br.readLine()) != null){
                lista.add(funcion.apply(linea));
            }
        } catch (IOException ex){
            System.out.println(ex.getMessage());
        }
    }
    
}
