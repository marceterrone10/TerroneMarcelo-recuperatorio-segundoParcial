package servicio;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;


public interface Inventariable<T> {
    /*Agregar eventos al inventario.
    ▪ Obtener eventos por índice.
    ▪ Eliminar eventos por índice.
    ▪ Filtrar:
    ▪ Por género musical (por ejemplo, mostrar solo los eventos de tipo ROCK).
    ▪ Por palabra clave en el nombre del evento.
    ▪ Buscar:
    ▪ Eventos dentro de un rango de fechas dado (usando LocalDate).
    ▪ Ordenar:
    ▪ Naturalmente por fecha.
    ▪ Usando Comparator para ordenar por nombre o artista.
    ▪ Persistencia:
    ▪ Guardar y cargar eventos en formato binario.
    ▪ Guardar y cargar eventos en formato CSV.*/
    
    void agregar(T item);
    
    T obtener(int indice);
    
    void eliminar(int indice);
    
    void mostrarTodos();
    
    List<T> filtrar(Predicate<T> predicado);
    
    List<T> buscarPorRango(LocalDate fechaInicio, LocalDate fechaFinal);
    
    void ordenarNatural();
    
    void ordenar(Comparator<T> criterio);
    
    void guardarEnBinario(String path);
    
    void cargarDesdeBinario(String path);
    
    void guardarEnCSV(String path);
    
    void cargarDesdeCSV(String path, Function<String, T> funcion);
    
    
}
